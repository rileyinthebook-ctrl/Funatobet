import os
import random
from datetime import datetime
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, jsonify, flash, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SESSION_SECRET', 'funato_secure_static_key_2026!')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///funato.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = False
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_NAME'] = 'funatobet_session'
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message = ''


# ─── Models ───────────────────────────────────────────────────────────────────

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    wallet = db.Column(db.Float, default=2000.0)
    is_admin = db.Column(db.Boolean, default=False)
    total_staked = db.Column(db.Float, default=0.0)
    total_won = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    bets = db.relationship('Bet', backref='user', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def net(self):
        return round(self.total_won - self.total_staked, 2)

    @property
    def pending_bets(self):
        return sum(1 for b in self.bets if b.status == 'pending')


class Match(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    teams = db.Column(db.String(300), nullable=False)
    short_a = db.Column(db.String(60))
    short_b = db.Column(db.String(60))
    odds_1 = db.Column(db.Float, default=1.85)
    odds_x = db.Column(db.Float, default=2.10)
    odds_2 = db.Column(db.Float, default=2.80)
    score_a = db.Column(db.Integer, default=0)
    score_b = db.Column(db.Integer, default=0)
    minute = db.Column(db.Integer, default=0)
    status = db.Column(db.String(20), default='upcoming')
    bets = db.relationship('Bet', backref='match', lazy=True)

    def result(self):
        if self.score_a > self.score_b:
            return 'home'
        elif self.score_b > self.score_a:
            return 'away'
        return 'draw'


class Bet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    match_id = db.Column(db.Integer, db.ForeignKey('match.id'), nullable=False)
    prediction = db.Column(db.String(100))
    stake = db.Column(db.Float)
    odds = db.Column(db.Float)
    payout = db.Column(db.Float)
    status = db.Column(db.String(20), default='pending')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated


# ─── Auth Routes ──────────────────────────────────────────────────────────────

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm', '')
        if not username or not email or not password:
            flash('All fields are required.', 'error')
        elif len(username) < 3:
            flash('Username must be at least 3 characters.', 'error')
        elif len(password) < 6:
            flash('Password must be at least 6 characters.', 'error')
        elif password != confirm:
            flash('Passwords do not match.', 'error')
        elif User.query.filter_by(username=username).first():
            flash('Username already taken.', 'error')
        elif User.query.filter_by(email=email).first():
            flash('Email already registered.', 'error')
        else:
            user = User(username=username, email=email, wallet=2000.0)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            login_user(user)
            flash('Welcome to FUNATOBET! Your ₦2,000 welcome bonus has been added.', 'success')
            return redirect(url_for('index'))
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('index'))
        flash('Invalid username or password.', 'error')
    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))


# ─── Main Routes ──────────────────────────────────────────────────────────────

@app.route('/')
@login_required
def index():
    matches = Match.query.filter(Match.status != 'finished').order_by(Match.id).all()
    user_bets = Bet.query.filter_by(user_id=current_user.id).order_by(Bet.created_at.desc()).limit(20).all()
    return render_template('index.html',
                           wallet=current_user.wallet,
                           matches=matches,
                           history=user_bets,
                           pending_count=current_user.pending_bets,
                           stats={
                               'total_staked': current_user.total_staked,
                               'total_won': current_user.total_won,
                               'net': current_user.net
                           })


@app.route('/dashboard')
@login_required
def dashboard():
    user_bets = Bet.query.filter_by(user_id=current_user.id).order_by(Bet.created_at.desc()).all()
    won = [b for b in user_bets if b.status == 'won']
    lost = [b for b in user_bets if b.status == 'lost']
    pending = [b for b in user_bets if b.status == 'pending']
    return render_template('dashboard.html',
                           bets=user_bets,
                           won=won,
                           lost=lost,
                           pending=pending)


@app.route('/place-bet', methods=['POST'])
@login_required
def place_bet():
    match_id = int(request.form.get('match_id'))
    stake = float(request.form.get('stake', 0))
    prediction = request.form.get('prediction')
    odds = float(request.form.get('odds', 0))

    match = db.session.get(Match, match_id)
    if match and match.status != 'finished' and 0 < stake <= current_user.wallet and odds > 0:
        current_user.wallet = round(current_user.wallet - stake, 2)
        current_user.total_staked = round(current_user.total_staked + stake, 2)
        payout = round(stake * odds, 2)
        bet = Bet(user_id=current_user.id, match_id=match_id,
                  prediction=prediction, stake=stake, odds=odds,
                  payout=payout, status='pending')
        db.session.add(bet)
        db.session.commit()
        flash(f'Bet placed! Potential win: ₦{payout}', 'success')
    else:
        flash('Could not place bet. Check your balance or stake amount.', 'error')
    return redirect(url_for('index'))


@app.route('/deposit', methods=['POST'])
@login_required
def deposit():
    amount = float(request.form.get('amount', 0))
    if amount >= 100:
        current_user.wallet = round(current_user.wallet + amount, 2)
        db.session.commit()
        flash(f'₦{amount:,.0f} added to your wallet!', 'success')
    return redirect(url_for('index'))


# ─── API Routes ───────────────────────────────────────────────────────────────

@app.route('/api/scores')
@login_required
def api_scores():
    matches = Match.query.filter_by(status='live').all()
    result = []
    for m in matches:
        if m.minute < 90:
            m.minute = min(90, m.minute + random.randint(0, 2))
        if random.random() < 0.07:
            if random.random() < 0.5:
                m.score_a += 1
            else:
                m.score_b += 1
        if m.minute >= 90:
            m.status = 'live'
        result.append({
            'id': m.id,
            'score_a': m.score_a,
            'score_b': m.score_b,
            'minute': m.minute,
            'status': m.status
        })
    db.session.commit()
    return jsonify(result)


@app.route('/api/wallet')
@login_required
def api_wallet():
    return jsonify({'wallet': current_user.wallet, 'pending': current_user.pending_bets})


@app.route('/sw.js')
def service_worker():
    resp = send_from_directory('static', 'sw.js')
    resp.headers['Content-Type'] = 'application/javascript'
    resp.headers['Service-Worker-Allowed'] = '/'
    return resp


@app.route('/manifest.json')
def manifest():
    return send_from_directory('static', 'manifest.json')


# ─── Admin Routes ─────────────────────────────────────────────────────────────

@app.route('/admin')
@admin_required
def admin():
    tab = request.args.get('tab', 'overview')
    users = User.query.order_by(User.created_at.desc()).all()
    matches = Match.query.order_by(Match.id).all()
    all_bets = Bet.query.order_by(Bet.created_at.desc()).limit(100).all()
    total_staked = db.session.query(db.func.sum(Bet.stake)).scalar() or 0
    total_paid = db.session.query(db.func.sum(Bet.payout)).filter_by(status='won').scalar() or 0
    return render_template('admin.html',
                           tab=tab,
                           users=users,
                           matches=matches,
                           all_bets=all_bets,
                           total_staked=total_staked,
                           total_paid=total_paid)


@app.route('/admin/match/add', methods=['POST'])
@admin_required
def admin_add_match():
    m = Match(
        teams=request.form.get('teams'),
        short_a=request.form.get('short_a'),
        short_b=request.form.get('short_b'),
        odds_1=float(request.form.get('odds_1', 1.85)),
        odds_x=float(request.form.get('odds_x', 2.10)),
        odds_2=float(request.form.get('odds_2', 2.80)),
        score_a=int(request.form.get('score_a', 0)),
        score_b=int(request.form.get('score_b', 0)),
        minute=int(request.form.get('minute', 0)),
        status=request.form.get('status', 'upcoming')
    )
    db.session.add(m)
    db.session.commit()
    flash('Match added.', 'success')
    return redirect(url_for('admin', tab='matches'))


@app.route('/admin/match/<int:mid>/update', methods=['POST'])
@admin_required
def admin_update_match(mid):
    m = db.session.get(Match, mid)
    if m:
        m.score_a = int(request.form.get('score_a', m.score_a))
        m.score_b = int(request.form.get('score_b', m.score_b))
        m.minute = int(request.form.get('minute', m.minute))
        m.status = request.form.get('status', m.status)
        db.session.commit()
        flash('Match updated.', 'success')
    return redirect(url_for('admin', tab='matches'))


@app.route('/admin/match/<int:mid>/settle', methods=['POST'])
@admin_required
def admin_settle_match(mid):
    m = db.session.get(Match, mid)
    if not m:
        return redirect(url_for('admin', tab='matches'))
    m.status = 'finished'
    result = m.result()
    pending_bets = Bet.query.filter_by(match_id=mid, status='pending').all()
    settled = 0
    for bet in pending_bets:
        won = False
        pred = bet.prediction.lower()
        if result == 'home' and 'win' in pred and m.short_a.lower() in pred:
            won = True
        elif result == 'away' and 'win' in pred and m.short_b.lower() in pred:
            won = True
        elif result == 'draw' and 'draw' in pred:
            won = True
        if won:
            bet.status = 'won'
            bet.user.wallet = round(bet.user.wallet + bet.payout, 2)
            bet.user.total_won = round(bet.user.total_won + bet.payout, 2)
        else:
            bet.status = 'lost'
        settled += 1
    db.session.commit()
    flash(f'Match settled. {settled} bets resolved.', 'success')
    return redirect(url_for('admin', tab='matches'))


@app.route('/admin/match/<int:mid>/delete', methods=['POST'])
@admin_required
def admin_delete_match(mid):
    m = db.session.get(Match, mid)
    if m:
        Bet.query.filter_by(match_id=mid).delete()
        db.session.delete(m)
        db.session.commit()
        flash('Match deleted.', 'success')
    return redirect(url_for('admin', tab='matches'))


@app.route('/admin/user/<int:uid>/toggle-admin', methods=['POST'])
@admin_required
def admin_toggle_admin(uid):
    user = db.session.get(User, uid)
    if user and user.id != current_user.id:
        user.is_admin = not user.is_admin
        db.session.commit()
    return redirect(url_for('admin', tab='users'))


# ─── Seed & Init ──────────────────────────────────────────────────────────────

def seed_data():
    if Match.query.count() == 0:
        initial = [
            Match(teams="College of Science and Computing vs College of Engineering and Technology",
                  short_a="Science & Comp", short_b="Engineering",
                  odds_1=1.85, odds_x=2.10, odds_2=2.80,
                  score_a=2, score_b=1, minute=64, status='live'),
            Match(teams="College of Agricultural Development vs College of Plant Science and Crop Production",
                  short_a="Agric Dev", short_b="Plant Sci",
                  odds_1=2.25, odds_x=3.00, odds_2=2.60,
                  score_a=0, score_b=0, minute=12, status='live'),
            Match(teams="College of Environmental Design vs College of Livestock Development",
                  short_a="Env Design", short_b="Livestock Dev",
                  odds_1=3.10, odds_x=2.90, odds_2=1.95,
                  score_a=1, score_b=1, minute=81, status='live'),
            Match(teams="College of Veterinary Medicine vs College of Natural Sciences",
                  short_a="Vet Medicine", short_b="Natural Sci",
                  odds_1=1.65, odds_x=3.20, odds_2=4.10,
                  score_a=0, score_b=0, minute=0, status='upcoming'),
            Match(teams="College of Management Sciences vs College of Social Sciences",
                  short_a="Management", short_b="Social Sci",
                  odds_1=2.00, odds_x=2.75, odds_2=3.30,
                  score_a=3, score_b=2, minute=45, status='live'),
            Match(teams="College of Law vs College of Education",
                  short_a="Law", short_b="Education",
                  odds_1=2.50, odds_x=3.10, odds_2=2.20,
                  score_a=1, score_b=0, minute=33, status='live'),
        ]
        db.session.add_all(initial)

    if not User.query.filter_by(is_admin=True).first():
        admin = User(username='admin', email='admin@funatobet.com',
                     wallet=0.0, is_admin=True)
        admin.set_password('FunatoAdmin2026!')
        db.session.add(admin)
        print("=" * 50)
        print("ADMIN ACCOUNT CREATED")
        print("  Username : admin")
        print("  Password : FunatoAdmin2026!")
        print("  Change this password immediately!")
        print("=" * 50)

    db.session.commit()


with app.app_context():
    db.create_all()
    seed_data()


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8000))
    app.run(host='0.0.0.0', port=port)
